package com.wipro.eb.exception;

@SuppressWarnings("serial")
public class InvalidReadingException extends Exception {
	public String toString()
	{
		return "Incorrect Reading" ;
	}
}
